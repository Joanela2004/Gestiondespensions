
package Modele;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import static javax.swing.JOptionPane.showMessageDialog;
import javax.swing.table.DefaultTableModel;
public class Tarif extends javax.swing.JFrame {
    public Tarif() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        javax.swing.JLabel Lnum_tarif = new javax.swing.JLabel();
        javax.swing.JLabel Ldiplome = new javax.swing.JLabel();
        javax.swing.JLabel Lcategorie = new javax.swing.JLabel();
        javax.swing.JLabel Lmontant = new javax.swing.JLabel();
        num_tarif = new javax.swing.JTextField();
        diplome = new javax.swing.JTextField();
        categorie = new javax.swing.JTextField();
        montant = new javax.swing.JTextField();
        jPanel1 = new javax.swing.JPanel();
        javax.swing.JButton Modifier = new javax.swing.JButton();
        javax.swing.JButton EnregistrerTarif = new javax.swing.JButton();
        javax.swing.JButton Supprimer = new javax.swing.JButton();
        javax.swing.JButton Valider = new javax.swing.JButton();
        Acceuil = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        jScrollPane1 = new javax.swing.JScrollPane();
        Table = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        setResizable(false);

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(204, 102, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Fiche de tarif");

        Lnum_tarif.setFont(new java.awt.Font("Trebuchet MS", 0, 18)); // NOI18N
        Lnum_tarif.setText("Numéro du tarif:");

        Ldiplome.setFont(new java.awt.Font("Trebuchet MS", 0, 18)); // NOI18N
        Ldiplome.setText("Diplome:");

        Lcategorie.setFont(new java.awt.Font("Trebuchet MS", 0, 18)); // NOI18N
        Lcategorie.setText("Catégorie");

        Lmontant.setFont(new java.awt.Font("Trebuchet MS", 0, 18)); // NOI18N
        Lmontant.setText("Montant:");

        Modifier.setFont(new java.awt.Font("Segoe UI", 3, 18)); // NOI18N
        Modifier.setText("Modifier");
        Modifier.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ModifierActionPerformed(evt);
            }
        });

        EnregistrerTarif.setFont(new java.awt.Font("Tahoma", 3, 18)); // NOI18N
        EnregistrerTarif.setText("Enregistrer");
        EnregistrerTarif.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EnregistrerTarifActionPerformed(evt);
            }
        });

        Supprimer.setFont(new java.awt.Font("Segoe UI", 3, 18)); // NOI18N
        Supprimer.setText("Supprimer");
        Supprimer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SupprimerActionPerformed(evt);
            }
        });

        Valider.setFont(new java.awt.Font("Segoe UI", 3, 18)); // NOI18N
        Valider.setText("Valider");
        Valider.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ValiderActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(16, 16, 16)
                        .addComponent(EnregistrerTarif)
                        .addGap(18, 18, 18)
                        .addComponent(Modifier, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(Supprimer))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(168, 168, 168)
                        .addComponent(Valider, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(21, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Modifier, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(EnregistrerTarif, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Supprimer, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(36, 36, 36)
                .addComponent(Valider, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(25, Short.MAX_VALUE))
        );

        Acceuil.setFont(new java.awt.Font("Segoe UI", 3, 18)); // NOI18N
        Acceuil.setText("Acceuil");
        Acceuil.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AcceuilActionPerformed(evt);
            }
        });

        Table.setFont(new java.awt.Font("Segoe Print", 1, 14)); // NOI18N
        Table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Numéro du tarif", "Diplome", "Catégorie", "Montant"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Integer.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(Table);
        if (Table.getColumnModel().getColumnCount() > 0) {
            Table.getColumnModel().getColumn(3).setMaxWidth(50);
        }

        jScrollPane2.setViewportView(jScrollPane1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(Lnum_tarif, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(Lmontant, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(montant, javax.swing.GroupLayout.PREFERRED_SIZE, 304, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(categorie, javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(Lcategorie, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(diplome, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 304, Short.MAX_VALUE)
                                .addComponent(Ldiplome, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(num_tarif, javax.swing.GroupLayout.Alignment.LEADING)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 441, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(76, 76, 76))))
            .addGroup(layout.createSequentialGroup()
                .addGap(287, 287, 287)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 277, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 253, Short.MAX_VALUE)
                .addComponent(Acceuil, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(Acceuil, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(Lnum_tarif, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(num_tarif, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(Ldiplome, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(diplome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(Lcategorie, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(categorie, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(Lmontant, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(montant, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 294, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(188, 188, 188))
        );

        setSize(new java.awt.Dimension(968, 632));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    public void  loadData(){
          try {
        Class.forName("org.postgresql.Driver");
        String url = "jdbc:postgresql://localhost:5432/projetjava";
        String user = "postgres";
        String pass = "12345";
        Connection con = DriverManager.getConnection(url, user, pass);
        Statement st = con.createStatement();
        DefaultTableModel model = new DefaultTableModel(new String[]{"num_tarif", "diplome", "categorie", "montant"}, 0);
        Table.setModel(model);
         String sql = "SELECT * FROM tarif";
        ResultSet rs = st.executeQuery(sql);
        String n,d,c,m;
        while(rs.next()){
            n=rs.getString("num_tarif");
            d=rs.getString("diplome");
            c=rs.getString("categorie");
            m=rs.getString("montant");
            model.addRow(new Object[]{n,d,c,m});
        }
    } catch (Exception e) {
        System.out.println("Erreur" + e.getMessage());
    }
    }
    
    
    private void EnregistrerTarifActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EnregistrerTarifActionPerformed
String nt,di,cat,mon,query;
  try {
        Class.forName("org.postgresql.Driver");
        String url = "jdbc:postgresql://localhost:5432/projetjava";
        String user = "postgres";
        String pass = "12345";
        Connection con = DriverManager.getConnection(url, user, pass);
        Statement st = con.createStatement();
        if ("".equals(num_tarif.getText())) {
            JOptionPane.showMessageDialog(new JFrame(), "Numero tarif obligatoire", "Dialog",
                    JOptionPane.ERROR_MESSAGE);
        } else if ("".equals(diplome.getText())) {
            JOptionPane.showMessageDialog(new JFrame(), "Diplome obligatoire", "Dialog", JOptionPane.ERROR_MESSAGE);
        } else if ("".equals(categorie.getText())) {
            JOptionPane.showMessageDialog(new JFrame(), "Categorie obligatoire", "Dialog", JOptionPane.ERROR_MESSAGE);
        } else if ("".equals(montant.getText())) {
            JOptionPane.showMessageDialog(new JFrame(), "Montant obligatoire", "Dialog", JOptionPane.ERROR_MESSAGE);
        } else {
            nt = num_tarif.getText();
            di = diplome.getText();
            cat = categorie.getText();
            mon = montant.getText();
            query = "INSERT INTO tarif (num_tarif, diplome, categorie, montant) VALUES('" + nt + "','" + di + "','" + cat + "','" + mon + "')";
            st.executeUpdate(query);
            num_tarif.setText("");
            diplome.setText("");
            categorie.setText("");
            montant.setText("");
            showMessageDialog(null,"Ajouté avec succès");
             loadData(); 
            con.close();
        }
    } catch (Exception e) {
        System.out.println("Erreur" + e.getMessage());
    }            
    }//GEN-LAST:event_EnregistrerTarifActionPerformed

    
    
    private void AcceuilActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AcceuilActionPerformed
        Tarif.super.dispose();
        MenuPrincipale men = new MenuPrincipale();
        men.setVisible(true);
    }//GEN-LAST:event_AcceuilActionPerformed

    private void ModifierActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ModifierActionPerformed
      // Récupérer l'index de la ligne sélectionnée dans le tableau
    int selectedRow = Table.getSelectedRow();

    // Vérifier si une ligne est sélectionnée
    if (selectedRow == -1) {
        JOptionPane.showMessageDialog(this, "Veuillez sélectionner une ligne à modifier", "Erreur", JOptionPane.ERROR_MESSAGE);
        return;
    }

    // Récupérer les valeurs des colonnes de la ligne sélectionnée
    String nt = Table.getValueAt(selectedRow, 0).toString();
    String di = Table.getValueAt(selectedRow, 1).toString();
    String cat = Table.getValueAt(selectedRow, 2).toString();
    String mon = Table.getValueAt(selectedRow, 3).toString();

    // Afficher les valeurs dans les champs correspondants
    num_tarif.setText(nt);
    diplome.setText(di);
    categorie.setText(cat);
    montant.setText(mon);
    }//GEN-LAST:event_ModifierActionPerformed

    
  
   
    private void SupprimerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SupprimerActionPerformed
        supprimerTarifSelectionnee();
    }//GEN-LAST:event_SupprimerActionPerformed

    private void ValiderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ValiderActionPerformed
       // Récupérer les valeurs des champs de saisie
    String nt = num_tarif.getText();
    String di = diplome.getText();
    String cat = categorie.getText();
    String mon = montant.getText();

    // Exécuter une requête de mise à jour pour modifier les valeurs dans la base de données
    try {
        Class.forName("org.postgresql.Driver");
        String url = "jdbc:postgresql://localhost:5432/projetjava";
        String user = "postgres";
        String pass = "12345";
        Connection con = DriverManager.getConnection(url, user, pass);
        String sql = "UPDATE tarif SET diplome=?, categorie=?, montant=? WHERE num_tarif=?";
        PreparedStatement stmt = con.prepareStatement(sql);
        stmt.setString(1, di);
        stmt.setString(2, cat);
        stmt.setLong(3, Long.parseLong(mon)); 
        stmt.setString(4, nt);
        stmt.executeUpdate();
        con.close();

        JOptionPane.showMessageDialog(this, "La ligne a été modifiée avec succès", "Succès", JOptionPane.INFORMATION_MESSAGE);

        // Mettre à jour les valeurs dans le tableau
        int selectedRow = Table.getSelectedRow();
        Table.setValueAt(nt, selectedRow, 0);
        Table.setValueAt(di, selectedRow, 1);
        Table.setValueAt(cat, selectedRow, 2);
        Table.setValueAt(mon, selectedRow, 3);
    } catch (SQLException ex) {
        Logger.getLogger(Tarif.class.getName()).log(Level.SEVERE, null, ex);
    } catch (ClassNotFoundException ex) {
        Logger.getLogger(Tarif.class.getName()).log(Level.SEVERE, null, ex);
    }
    }//GEN-LAST:event_ValiderActionPerformed
private void supprimerTarifSelectionnee() {

    int selectedRow = Table.getSelectedRow();
    
    if (selectedRow == -1) {
        JOptionPane.showMessageDialog(this, "Aucun tarif sélectionnée", "Erreur", JOptionPane.ERROR_MESSAGE);
        return;
    }
    
    String num_tarif = Table.getValueAt(selectedRow, 0).toString(); // Supposant que la colonne IM est à l'index 0
    
    try {
        Class.forName("org.postgresql.Driver");
        String url = "jdbc:postgresql://localhost:5432/projetjava";
        String user = "postgres";
        String pass = "150604";
        Connection con = DriverManager.getConnection(url, user, pass);
        
        String sql = "DELETE FROM tarif WHERE num_tarif = ?";
        PreparedStatement pstmt = con.prepareStatement(sql);
        pstmt.setString(1, num_tarif);
        
        int rowsDeleted = pstmt.executeUpdate();
        con.close();
        
        if (rowsDeleted > 0) {
            JOptionPane.showMessageDialog(this, "Suppression effectuée avec succès", "Succès", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this, "La suppression a échoué", "Erreur", JOptionPane.ERROR_MESSAGE);
        }
        
        loadData(); // Recharger les données dans la table après la suppression
    } catch (ClassNotFoundException | SQLException e) {
        System.out.println("Erreur: " + e.getMessage());
    }
}
   
    /**
     * @param args the command line arguments
     */
     public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Personne.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Personne.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Personne.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Personne.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Tarif().setVisible(true);
              /*    View x= new View();
               x.loadData();   
               x.setVisible(true);*/
            }
        });
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Acceuil;
    private javax.swing.JTable Table;
    private javax.swing.JTextField categorie;
    private javax.swing.JTextField diplome;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextField montant;
    private javax.swing.JTextField num_tarif;
    // End of variables declaration//GEN-END:variables
}
