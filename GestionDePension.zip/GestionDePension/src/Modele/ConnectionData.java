/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modele;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
public class ConnectionData {
    public static void main(String[] args) {
        Connection conn = null;
        
        try {
            // Chargement du pilote JDBC
            Class.forName("org.postgresql.Driver");
            
            // Connexion à la base de données
            String url = "jdbc:postgresql://localhost:5432/projetjava";
            String utilisateur = "postgres";
            String motDePasse = "12345";
            conn = DriverManager.getConnection(url, utilisateur, motDePasse);
            
            if (conn != null) {
                System.out.println("Connexion à la base de données établie !");
                // Effectuez vos opérations sur la base de données ici
            }
        } catch (SQLException e) {
            System.out.println("Erreur de connexion à la base de données : " + e.getMessage());
        } catch (ClassNotFoundException e) {
            System.out.println("Le pilote PostgreSQL n'a pas été trouvé. Assurez-vous d'inclure le pilote JDBC dans votre projet.");
        } finally {
            // Fermeture de la connexion
            if (conn != null) {
                try {
                    conn.close();
                    System.out.println("Connexion à la base de données fermée !");
                } catch (SQLException e) {
                    System.out.println("Erreur lors de la fermeture de la connexion : " + e.getMessage());
                }
            }
        }
    }
}
