/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Modele;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;
import java.util.Scanner;
import javax.swing.table.DefaultTableModel;


public class Conjoint extends javax.swing.JFrame {

    public Conjoint() {
        initComponents();
        
    }
    public void  loadData(){
          try {
        Class.forName("org.postgresql.Driver");
        String url = "jdbc:postgresql://localhost:5432/projetjava";
        String user = "postgres";
        String pass = "12345";
        Connection con = DriverManager.getConnection(url, user, pass);
        Statement st = con.createStatement();
        DefaultTableModel model = new DefaultTableModel(new String[]{"numPension","NomConjoint", "PrenomConjoint","montant"}, 0);
        Table.setModel(model);
         String sql = "SELECT * FROM conjoint";
        ResultSet rs = st.executeQuery(sql);
        String   num, nc,pc,mon;
        while(rs.next()){
            num=rs.getString("numPension");
            nc=rs.getString("NomConjoint");
            pc=rs.getString("PrenomConjoint");
            mon=rs.getString("montant");
            model.addRow(new Object[]{num, nc,pc,mon});
        }
    } catch (Exception e) {
        System.out.println("Erreur" + e.getMessage());
    } 
    }
    
   
// Étape 1 : Identifier le décès d'une personne pensionnaire
// Supposons que vous ayez une méthode qui détecte le décès d'une personne pensionnaire
public void detecterDecesPersonne(String IM) {
    // Votre logique de détection du décès ici
        
    // Le statut est vrai (vivant)
    // Effectuez des opérations pour un statut vivant
    Scanner scanner=new Scanner(System.in);
    System.out.print("Entrez un diplome:");
    String diplome=scanner.nextLine();
calculerMontantConjoint("diplome");
  
}

// Étape 2 : Mettre à jour le statut de la personne décédée
public void mettreAJourStatutDecede(String IM) {
    try {
        Class.forName("org.postgresql.Driver");
        String url = "jdbc:postgresql://localhost:5432/projetjava";
        String user = "postgres";
        String pass = "12345";
        Connection con = DriverManager.getConnection(url, user, pass);

        String sql = "UPDATE personne SET statut = false WHERE IM = ?";
        PreparedStatement stmt = con.prepareStatement(sql);
        stmt.setString(1, IM);
        stmt.executeUpdate();

        con.close();
    } catch (SQLException ex) {
        ex.printStackTrace();
    } catch (ClassNotFoundException ex) {
        ex.printStackTrace();
    }
}

// Étape 3 : Calculer le montant à attribuer au conjoint
public int calculerMontantConjoint(String diplome) {
    try {
        Class.forName("org.postgresql.Driver");
        String url = "jdbc:postgresql://localhost:5432/projetjava";
        String user = "postgres";
        String pass = "12345";
        Connection con = DriverManager.getConnection(url, user, pass);

        String sql = "SELECT montant FROM tarif WHERE diplome = ?";
        PreparedStatement stmt = con.prepareStatement(sql);
        stmt.setString(1, diplome);
        ResultSet rs = stmt.executeQuery();

        if (rs.next()) {
            int montant = rs.getInt("montant");
            int montantConjoint = (int) (montant * 0.4); // 40% du montant
            return montantConjoint;
        }
	else{
	    int montant = rs.getInt("montant");
            int montantConjoint = (int) (montant); // 100% du montant
            return montantConjoint;
 
}

          
    } catch (SQLException ex) {
        ex.printStackTrace();
    } catch (ClassNotFoundException ex) {
        ex.printStackTrace();
    }

    return 0;
}

// Étape 4 : Insérer une nouvelle entrée pour le conjoint
public void insererConjoint(String numPension, String nomConjoint, String prenomConjoint, int montant) {
    try {
        Class.forName("org.postgresql.Driver");
        String url = "jdbc:postgresql://localhost:5432/projetjava";
        String user = "postgres";
        String pass = "12345";
        Connection con = DriverManager.getConnection(url, user, pass);

        String sql = "INSERT INTO conjoint (numPension, NomConjoint, PrenomConjoint, montant) VALUES (?, ?, ?, ?)";
        PreparedStatement stmt = con.prepareStatement(sql);
        stmt.setString(1, numPension);
        stmt.setString(2, nomConjoint);
        stmt.setString(3, prenomConjoint);
        stmt.setInt(4, montant);
        stmt.executeUpdate();

        con.close();
    } catch (SQLException ex) {
        ex.printStackTrace();
    } catch (ClassNotFoundException ex) {
        ex.printStackTrace();
    }
}

// Étape 5 : Mettre à jour les informations du conjoint dans la table "PERSONNE"
public void mettreAJourInformationsConjoint(String numPension, String nomConjoint, String prenomConjoint) {
    try {
        Class.forName("org.postgresql.Driver");
        String url = "jdbc:postgresql://localhost:5432/projetjava";
        String user = "postgres";
        String pass = "12345";
        Connection con = DriverManager.getConnection(url, user, pass);

        String sql = "UPDATE personne SET NomConjoint = ?, PrenomConjoint = ? WHERE numPension = ?";
        PreparedStatement stmt = con.prepareStatement(sql);
        stmt.setString(1, nomConjoint);
        stmt.setString(2, prenomConjoint);
        stmt.setString(3, numPension);
        stmt.executeUpdate();

        con.close();
    } catch (SQLException ex) {
        ex.printStackTrace();
    } catch (ClassNotFoundException ex) {
        ex.printStackTrace();
    }
}

// Étape 6 : Effectuer le paiement au conjoint
public void effectuerPaiementConjoint(String IM, String num_tarif, Date date) {
    try {
        Class.forName("org.postgresql.Driver");
        String url = "jdbc:postgresql://localhost:5432/projetjava";
        String user = "postgres";
        String pass = "12345";
        Connection con = DriverManager.getConnection(url, user, pass);

        String sql = "INSERT INTO payer (IM, num_tarif, date) VALUES (?, ?, ?)";
        PreparedStatement stmt = con.prepareStatement(sql);
        stmt.setString(1, IM);
        stmt.setString(2, num_tarif);
        stmt.setDate(3, (java.sql.Date) date);
        stmt.executeUpdate();

        con.close();
    } catch (SQLException ex) {
        ex.printStackTrace();
    } catch (ClassNotFoundException ex) {
        ex.printStackTrace();
    }
}
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jScrollPane1 = new javax.swing.JScrollPane();
        Table = new javax.swing.JTable();
        Acceuil = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(204, 102, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Fiche de conjoint");

        Table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Numero de pension", "Nom du conjont", "Prenom du conjoint", "Montant"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        Table.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
                TableAncestorAdded(evt);
            }
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });
        jScrollPane1.setViewportView(Table);

        jScrollPane2.setViewportView(jScrollPane1);

        Acceuil.setFont(new java.awt.Font("Segoe UI", 3, 18)); // NOI18N
        Acceuil.setText("Acceuil");
        Acceuil.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AcceuilActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(153, 153, 153)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 619, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(155, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGap(293, 293, 293)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 277, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(Acceuil, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(38, 38, 38))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Acceuil, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(55, 55, 55)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(91, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void TableAncestorAdded(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_TableAncestorAdded
        // TODO add your handling code here:
    }//GEN-LAST:event_TableAncestorAdded

    private void AcceuilActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AcceuilActionPerformed
        Conjoint.super.dispose();
        MenuPrincipale men = new MenuPrincipale();
        men.setVisible(true);
    }//GEN-LAST:event_AcceuilActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Conjoint.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Conjoint.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Conjoint.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Conjoint.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Conjoint().setVisible(true);
                new Tarif().setVisible(true);
            }
            
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Acceuil;
    private javax.swing.JTable Table;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    // End of variables declaration//GEN-END:variables

    private int calculerMontantPension(String diplome) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    
    }

    
}
