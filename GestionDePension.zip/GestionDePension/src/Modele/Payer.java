package Modele;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import static javax.swing.JOptionPane.showMessageDialog;
import javax.swing.table.DefaultTableModel;

public class Payer extends javax.swing.JFrame {
 public Payer() {
        initComponents();
    }
 
   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        javax.swing.JLabel LIM = new javax.swing.JLabel();
        IM = new javax.swing.JTextField();
        javax.swing.JLabel LIM1 = new javax.swing.JLabel();
        javax.swing.JLabel LIM2 = new javax.swing.JLabel();
        num_tarif = new javax.swing.JTextField();
        date = new javax.swing.JTextField();
        jPanel2 = new javax.swing.JPanel();
        Enregistrer = new javax.swing.JButton();
        Supprimer = new javax.swing.JButton();
        Modifier = new javax.swing.JButton();
        Valider = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        jScrollPane1 = new javax.swing.JScrollPane();
        Table = new javax.swing.JTable();
        Acceuil = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(204, 102, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Fiche de paiement");

        LIM.setFont(new java.awt.Font("Trebuchet MS", 0, 18)); // NOI18N
        LIM.setText("Imatriculation:");

        LIM1.setFont(new java.awt.Font("Trebuchet MS", 0, 18)); // NOI18N
        LIM1.setText("Numéro du tarif:");

        LIM2.setFont(new java.awt.Font("Trebuchet MS", 0, 18)); // NOI18N
        LIM2.setText("Date de paiement:");

        Enregistrer.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        Enregistrer.setText("Enregistrer");
        Enregistrer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EnregistrerActionPerformed(evt);
            }
        });

        Supprimer.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        Supprimer.setText("Supprimer");
        Supprimer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SupprimerActionPerformed(evt);
            }
        });

        Modifier.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        Modifier.setText("Modifier");
        Modifier.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ModifierActionPerformed(evt);
            }
        });

        Valider.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        Valider.setText("Valider");
        Valider.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ValiderActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(Enregistrer)
                .addGap(38, 38, 38)
                .addComponent(Modifier)
                .addGap(43, 43, 43)
                .addComponent(Supprimer))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(148, 148, 148)
                .addComponent(Valider)
                .addGap(143, 143, 143))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(43, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Enregistrer)
                    .addComponent(Modifier)
                    .addComponent(Supprimer))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(Valider)
                .addGap(65, 65, 65))
        );

        Table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "IM", "Numero du tarif", "date"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(Table);

        jScrollPane2.setViewportView(jScrollPane1);

        Acceuil.setFont(new java.awt.Font("Segoe UI", 3, 18)); // NOI18N
        Acceuil.setText("Acceuil");
        Acceuil.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AcceuilActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(LIM, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(776, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(LIM2, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(date, javax.swing.GroupLayout.PREFERRED_SIZE, 208, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(num_tarif, javax.swing.GroupLayout.PREFERRED_SIZE, 208, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(IM, javax.swing.GroupLayout.PREFERRED_SIZE, 208, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(LIM1, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(76, 76, 76))))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 277, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(217, 217, 217)
                .addComponent(Acceuil, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(39, 39, 39))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Acceuil, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(LIM, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(IM, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(31, 31, 31)
                        .addComponent(LIM1, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(num_tarif, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(30, 30, 30)
                        .addComponent(LIM2, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(date, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(68, 68, 68)
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 333, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 87, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(20, 20, 20))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
public void  loadData(){
          try {
        Class.forName("org.postgresql.Driver");
        String url = "jdbc:postgresql://localhost:5432/projetjava";
        String user = "postgres";
        String pass = "12345";
        Connection con = DriverManager.getConnection(url, user, pass);
        Statement st = con.createStatement();
        DefaultTableModel model = new DefaultTableModel(new String[]{"IM","num_tarif", "date"}, 0);
        Table.setModel(model);
         String sql = "SELECT * FROM payer";
        ResultSet rs = st.executeQuery(sql);
        String im,nt,d;
        while(rs.next()){
            im=rs.getString("IM");
            nt=rs.getString("num_tarif");
            d=rs.getString("date");
            model.addRow(new Object[]{im,nt,d});
        }
    } catch (Exception e) {
        System.out.println("Erreur" + e.getMessage());
    } 
    }



    private void EnregistrerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EnregistrerActionPerformed
String im,nt,d,query;
try {
        Class.forName("org.postgresql.Driver");
        String url = "jdbc:postgresql://localhost:5432/projetjava";
        String user = "postgres";
        String pass = "12345";
        Connection con = DriverManager.getConnection(url, user, pass);
        Statement st = con.createStatement();
        if ("".equals(num_tarif.getText())) {
            JOptionPane.showMessageDialog(new JFrame(), "Numero tarif obligatoire", "Dialog",
                    JOptionPane.ERROR_MESSAGE);
        } else if ("".equals(date.getText())) {
            JOptionPane.showMessageDialog(new JFrame(), "Date obligatoire", "Dialog", JOptionPane.ERROR_MESSAGE);
        } else if ("".equals(IM.getText())) {
            JOptionPane.showMessageDialog(new JFrame(), "IM obligatoire", "Dialog", JOptionPane.ERROR_MESSAGE);
        } else{
            im = IM.getText();
            nt = num_tarif.getText();
            d = date.getText();
            query = "INSERT INTO payer (IM,num_tarif, date) VALUES('" + im + "','" + nt + "','" + d + "')";
            st.executeUpdate(query);
            IM.setText("");
            num_tarif.setText("");
            date.setText("");
            showMessageDialog(null,"Ajouté avec succès");
            loadData(); 
            con.close();
        }
    } catch (Exception e) {
        System.out.println("Erreur" + e.getMessage());
    }
    }//GEN-LAST:event_EnregistrerActionPerformed

    
    
    private void AcceuilActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AcceuilActionPerformed
        Payer.super.dispose();
        MenuPrincipale pa = new MenuPrincipale();
        pa.setVisible(true);
    }//GEN-LAST:event_AcceuilActionPerformed

    private void ModifierActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ModifierActionPerformed
        // Récupérer l'index de la ligne sélectionnée dans le tableau
    int selectedRow = Table.getSelectedRow();

    // Vérifier si une ligne est sélectionnée
    if (selectedRow == -1) {
        JOptionPane.showMessageDialog(this, "Veuillez sélectionner une ligne à modifier", "Erreur", JOptionPane.ERROR_MESSAGE);
        return;
    }

    // Récupérer les valeurs des colonnes de la ligne sélectionnée
    String im = Table.getValueAt(selectedRow, 0).toString();
    String nt = Table.getValueAt(selectedRow, 1).toString();
    String d = Table.getValueAt(selectedRow, 2).toString();
   

    IM.setText(im);
    num_tarif.setText(nt);
    date.setText(d);
   
    }//GEN-LAST:event_ModifierActionPerformed

    private void SupprimerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SupprimerActionPerformed
        supprimerPayerSelectionnee();
    }//GEN-LAST:event_SupprimerActionPerformed

    private void ValiderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ValiderActionPerformed
    String im = IM.getText();
    String nt = num_tarif.getText();
    String d = date.getText();
    

    // Exécuter une requête de mise à jour pour modifier les valeurs dans la base de données
    try {
        Class.forName("org.postgresql.Driver");
        String url = "jdbc:postgresql://localhost:5432/projetjava";
        String user = "postgres";
        String pass = "12345";
        Connection con = DriverManager.getConnection(url, user, pass);
        String sql = "UPDATE payer SET num_tarif=?, date=? WHERE IM=?";
        PreparedStatement stmt = con.prepareStatement(sql);
        stmt.setString(1, im);
        stmt.setString(2, nt);
        stmt.setString(3, d);
        stmt.executeUpdate();
        con.close();

        JOptionPane.showMessageDialog(this, "La ligne a été modifiée avec succès", "Succès", JOptionPane.INFORMATION_MESSAGE);

        // Mettre à jour les valeurs dans le tableau
        int selectedRow = Table.getSelectedRow();
        Table.setValueAt(im, selectedRow, 0);
        Table.setValueAt(nt, selectedRow, 1);
        Table.setValueAt(d, selectedRow, 2);
     
    } catch (SQLException ex) {
        Logger.getLogger(Payer.class.getName()).log(Level.SEVERE, null, ex);
    } catch (ClassNotFoundException ex) {
        Logger.getLogger(Payer.class.getName()).log(Level.SEVERE, null, ex);
    }
    }//GEN-LAST:event_ValiderActionPerformed
private void supprimerPayerSelectionnee() {

    int selectedRow = Table.getSelectedRow();
    
    if (selectedRow == -1) {
        JOptionPane.showMessageDialog(this, "Aucune IM sélectionnée", "Erreur", JOptionPane.ERROR_MESSAGE);
        return;
    }
    
    String IM = Table.getValueAt(selectedRow, 0).toString(); // Supposant que la colonne IM est à l'index 0
    
    try {
        Class.forName("org.postgresql.Driver");
        String url = "jdbc:postgresql://localhost:5432/projetjava";
        String user = "postgres";
        String pass = "12345";
        Connection con = DriverManager.getConnection(url, user, pass);
        
        String sql = "DELETE FROM payer WHERE IM = ?";
        PreparedStatement pstmt = con.prepareStatement(sql);
        pstmt.setString(1, IM);
        
        int rowsDeleted = pstmt.executeUpdate();
        con.close();
        
        if (rowsDeleted > 0) {
            JOptionPane.showMessageDialog(this, "Suppression effectuée avec succès", "Succès", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this, "La suppression a échoué", "Erreur", JOptionPane.ERROR_MESSAGE);
        }
        
        loadData(); // Recharger les données dans la table après la suppression
    } catch (ClassNotFoundException | SQLException e) {
        System.out.println("Erreur: " + e.getMessage());
    }
}
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Payer().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Acceuil;
    private javax.swing.JButton Enregistrer;
    private javax.swing.JTextField IM;
    private javax.swing.JButton Modifier;
    private javax.swing.JButton Supprimer;
    private javax.swing.JTable Table;
    private javax.swing.JButton Valider;
    private javax.swing.JTextField date;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextField num_tarif;
    // End of variables declaration//GEN-END:variables

    
}
